package cn.itcast.ssm.po;

public class UsersCustom extends Users {

}
