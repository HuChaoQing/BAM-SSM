package cn.itcast.ssm.po;

public class Doctor {
    private Integer doctorid;

    private String doctorname;

    private Integer doctorrankid;

    public Integer getDoctorid() {
        return doctorid;
    }

    public void setDoctorid(Integer doctorid) {
        this.doctorid = doctorid;
    }

    public String getDoctorname() {
        return doctorname;
    }

    public void setDoctorname(String doctorname) {
        this.doctorname = doctorname == null ? null : doctorname.trim();
    }

    public Integer getDoctorrankid() {
        return doctorrankid;
    }

    public void setDoctorrankid(Integer doctorrankid) {
        this.doctorrankid = doctorrankid;
    }
}