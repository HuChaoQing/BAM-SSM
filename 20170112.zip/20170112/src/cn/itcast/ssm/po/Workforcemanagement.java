package cn.itcast.ssm.po;

public class Workforcemanagement {
    private Integer workforcemanagetid;

    private Integer outpatientserviceid;

    private Integer doctorid;

    public Integer getWorkforcemanagetid() {
        return workforcemanagetid;
    }

    public void setWorkforcemanagetid(Integer workforcemanagetid) {
        this.workforcemanagetid = workforcemanagetid;
    }

    public Integer getOutpatientserviceid() {
        return outpatientserviceid;
    }

    public void setOutpatientserviceid(Integer outpatientserviceid) {
        this.outpatientserviceid = outpatientserviceid;
    }

    public Integer getDoctorid() {
        return doctorid;
    }

    public void setDoctorid(Integer doctorid) {
        this.doctorid = doctorid;
    }
}