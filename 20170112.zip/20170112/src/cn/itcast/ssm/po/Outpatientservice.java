package cn.itcast.ssm.po;

public class Outpatientservice {
    private Integer outpatientserviceid;

    private Integer officeid;

    private String outpatientservicename;

    public Integer getOutpatientserviceid() {
        return outpatientserviceid;
    }

    public void setOutpatientserviceid(Integer outpatientserviceid) {
        this.outpatientserviceid = outpatientserviceid;
    }

    public Integer getOfficeid() {
        return officeid;
    }

    public void setOfficeid(Integer officeid) {
        this.officeid = officeid;
    }

    public String getOutpatientservicename() {
        return outpatientservicename;
    }

    public void setOutpatientservicename(String outpatientservicename) {
        this.outpatientservicename = outpatientservicename == null ? null : outpatientservicename.trim();
    }
}