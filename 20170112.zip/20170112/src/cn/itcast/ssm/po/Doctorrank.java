package cn.itcast.ssm.po;

public class Doctorrank {
    private Integer doctorrankid;

    private String doctorrankname;

    public Integer getDoctorrankid() {
        return doctorrankid;
    }

    public void setDoctorrankid(Integer doctorrankid) {
        this.doctorrankid = doctorrankid;
    }

    public String getDoctorrankname() {
        return doctorrankname;
    }

    public void setDoctorrankname(String doctorrankname) {
        this.doctorrankname = doctorrankname == null ? null : doctorrankname.trim();
    }
}