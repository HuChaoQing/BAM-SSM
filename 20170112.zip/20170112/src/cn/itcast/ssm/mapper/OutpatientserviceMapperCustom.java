package cn.itcast.ssm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.itcast.ssm.po.Outpatientservice;

public interface OutpatientserviceMapperCustom {
        
	List<Outpatientservice> selectOutPatById(@Param("officeId") Integer id) throws Exception;
	
}
