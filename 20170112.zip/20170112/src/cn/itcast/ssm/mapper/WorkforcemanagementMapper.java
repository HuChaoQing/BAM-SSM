package cn.itcast.ssm.mapper;

import cn.itcast.ssm.po.Workforcemanagement;
import cn.itcast.ssm.po.WorkforcemanagementExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface WorkforcemanagementMapper {
    long countByExample(WorkforcemanagementExample example);

    int deleteByExample(WorkforcemanagementExample example);

    int deleteByPrimaryKey(Integer workforcemanagetid);

    int insert(Workforcemanagement record);

    int insertSelective(Workforcemanagement record);

    List<Workforcemanagement> selectByExample(WorkforcemanagementExample example);

    Workforcemanagement selectByPrimaryKey(Integer workforcemanagetid);

    int updateByExampleSelective(@Param("record") Workforcemanagement record, @Param("example") WorkforcemanagementExample example);

    int updateByExample(@Param("record") Workforcemanagement record, @Param("example") WorkforcemanagementExample example);

    int updateByPrimaryKeySelective(Workforcemanagement record);

    int updateByPrimaryKey(Workforcemanagement record);
}