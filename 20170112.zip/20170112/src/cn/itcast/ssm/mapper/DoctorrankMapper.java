package cn.itcast.ssm.mapper;

import cn.itcast.ssm.po.Doctorrank;
import cn.itcast.ssm.po.DoctorrankExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DoctorrankMapper {
    long countByExample(DoctorrankExample example);

    int deleteByExample(DoctorrankExample example);

    int deleteByPrimaryKey(Integer doctorrankid);

    int insert(Doctorrank record);

    int insertSelective(Doctorrank record);

    List<Doctorrank> selectByExample(DoctorrankExample example);

    Doctorrank selectByPrimaryKey(Integer doctorrankid);

    int updateByExampleSelective(@Param("record") Doctorrank record, @Param("example") DoctorrankExample example);

    int updateByExample(@Param("record") Doctorrank record, @Param("example") DoctorrankExample example);

    int updateByPrimaryKeySelective(Doctorrank record);

    int updateByPrimaryKey(Doctorrank record);
}