package cn.itcast.ssm.mapper;

import org.apache.ibatis.annotations.Param;

import cn.itcast.ssm.po.UsersCustom;

public interface UsersMapperCustom {

	public UsersCustom findUserToLogim(@Param("userc") UsersCustom usersCustom);
}
