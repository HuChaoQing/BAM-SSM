package cn.itcast.ssm.mapper;

import cn.itcast.ssm.po.Outpatientservice;
import cn.itcast.ssm.po.OutpatientserviceExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OutpatientserviceMapper {
    long countByExample(OutpatientserviceExample example);

    int deleteByExample(OutpatientserviceExample example);

    int deleteByPrimaryKey(Integer outpatientserviceid);

    int insert(Outpatientservice record);

    int insertSelective(Outpatientservice record);

    List<Outpatientservice> selectByExample(OutpatientserviceExample example);
    
    Outpatientservice selectByPrimaryKey(Integer outpatientserviceid);

    int updateByExampleSelective(@Param("record") Outpatientservice record, @Param("example") OutpatientserviceExample example);

    int updateByExample(@Param("record") Outpatientservice record, @Param("example") OutpatientserviceExample example);

    int updateByPrimaryKeySelective(Outpatientservice record);

    int updateByPrimaryKey(Outpatientservice record);
}