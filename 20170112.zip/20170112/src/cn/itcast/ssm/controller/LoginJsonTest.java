//package cn.itcast.ssm.controller;
//
//
//import javax.servlet.http.HttpServletRequest;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpRequest;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.ResponseBody;
//
//import com.taobao.api.ApiException;
//import com.taobao.api.DefaultTaobaoClient;
//import com.taobao.api.TaobaoClient;
//import com.taobao.api.request.AlibabaAliqinFcSmsNumSendRequest;
//import com.taobao.api.response.AlibabaAliqinFcSmsNumSendResponse;
//
//import cn.itcast.ssm.po.UserCustom;
//import cn.itcast.ssm.service.UserService;
//
//@Controller
//@RequestMapping("/login")
//public class LoginJsonTest {
//	
//	@Autowired
//	private UserService userService;
//	
//	@RequestMapping("/toLogin")
//	public String toLogin(){
//		return "/jsonTest/login2";		
//	}
//	
//	//获取验证码
//	@RequestMapping("/getYanZhengMa")
//	public @ResponseBody Integer getYanZhengMa(HttpServletRequest request ) throws Exception{
//		 	
//		Integer code  =  (int)((Math.random()*9+1)*100000);  //产生验证码	
//		System.out.println(code);	 
////		String url="http://gw.api.taobao.com/router/rest";   //请求服务器网址 18211499487
////		String appkey="23741875";  // App证书
////		String secret="001d81475fb177c86ee940a44b8d7879"; //App证书
//        String phoneNumber=request.getParameter("phone").toString();; //输入手机号码
////		
////		TaobaoClient client = new DefaultTaobaoClient(url, appkey, secret);
////		AlibabaAliqinFcSmsNumSendRequest req = new AlibabaAliqinFcSmsNumSendRequest();
////		req.setExtend( "" );  //公共回传参数 
////		req.setSmsType( "normal" );  //短信类型
////		req.setSmsFreeSignName( "医疗THIS" );  //短信签名
////		req.setSmsParamString( "{\"code\":"+code+"}" );   //发送参数
////		req.setRecNum(phoneNumber);  //短信接收号码
////		req.setSmsTemplateCode( "SMS_122420004" );   //短信模板ID
////		
////		AlibabaAliqinFcSmsNumSendResponse rsp = client.execute(req);
////		
////		System.out.println(rsp.getBody());
//		
////		 model.addAttribute("code", code); 
//		
//		return code;
//		
//	}
//	
//	
//	//获取key/value格式
//	@RequestMapping("/toMain")
//	public @ResponseBody UserCustom toMain(UserCustom  userCustom ) throws Exception{
//						
//		UserCustom userList  = userService.selectUserIf(userCustom);   		 
//		return userList;	
//		
//	}
//	
//	//获取json格式
//	@RequestMapping("/toJsonMain")
//	public @ResponseBody UserCustom toJsonMain(@RequestBody UserCustom  userCustom ) throws Exception{
//			
//		UserCustom userList  =userService.selectUserIf(userCustom);   		 
//		return userList;		
//		
//	}
//	
//	
//	@RequestMapping("/goMain")
//	public String goMain(){
//		return "/jsonTest/main";
//		
//	}
//	
//
//
//}
