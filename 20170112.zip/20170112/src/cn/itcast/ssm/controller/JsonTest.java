//package cn.itcast.ssm.controller;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.ResponseBody;
//
//import cn.itcast.ssm.po.UserCustom;
//
///**
// * json交互测试
// * @author HCQ
// *
// */
//
//@Controller
//public class JsonTest {
//	//请求json（商品信息），输出json (商品信息)
//	//@RequestBody 将请求的商品信息的json串转成userCustom对象
//	//@ResponseBody 将userCustom 转成json输出
//	@RequestMapping("/requestJson")
//	public @ResponseBody  UserCustom requestJson(@RequestBody UserCustom userCustom){
//		
//		//@ResponseBody 将userCustom 转成json输出
//		return userCustom;
//	}
//	
//	//请求key/value
//	@RequestMapping("/responseJson")
//	public @ResponseBody UserCustom responseJson(UserCustom userCustom ){
//		
//		return userCustom;
//		
//		
//	}
//	
//
//}
