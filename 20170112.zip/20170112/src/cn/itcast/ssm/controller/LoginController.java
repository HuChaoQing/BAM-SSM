package cn.itcast.ssm.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.itcast.ssm.po.Office;
import cn.itcast.ssm.po.Outpatientservice;

import cn.itcast.ssm.po.UsersCustom;
import cn.itcast.ssm.service.UsersService;

@Controller

@RequestMapping("/logins")
public class LoginController {
	
	@Autowired
	private UsersService usersService;
	
	
	//获取验证码
		@RequestMapping("/getYanZhengMa")
		public @ResponseBody Integer getYanZhengMa(HttpServletRequest request ) throws Exception{
			 	
			Integer code  =  (int)((Math.random()*9+1)*100000);  //产生验证码	
			System.out.println(code);	 
//			String url="http://gw.api.taobao.com/router/rest";   //请求服务器网址 18211499487
//			String appkey="23741875";  // App证书
//			String secret="001d81475fb177c86ee940a44b8d7879"; //App证书
	        String phoneNumber=request.getParameter("phone").toString();; //输入手机号码
//			
//			TaobaoClient client = new DefaultTaobaoClient(url, appkey, secret);
//			AlibabaAliqinFcSmsNumSendRequest req = new AlibabaAliqinFcSmsNumSendRequest();
//			req.setExtend( "" );  //公共回传参数 
//			req.setSmsType( "normal" );  //短信类型
//			req.setSmsFreeSignName( "医疗THIS" );  //短信签名
//			req.setSmsParamString( "{\"code\":"+code+"}" );   //发送参数
//			req.setRecNum(phoneNumber);  //短信接收号码
//			req.setSmsTemplateCode( "SMS_122420004" );   //短信模板ID
//			
//			AlibabaAliqinFcSmsNumSendResponse rsp = client.execute(req);
//			
//			System.out.println(rsp.getBody());
			
//			 model.addAttribute("code", code); 
			
			return code;
			
		}
		
	//注册用户
	@RequestMapping("/insertUser")
	   public @ResponseBody  String insertUser(@RequestBody UsersCustom usersCustom)throws Exception{
		 
		Integer num= usersService.insertUser(usersCustom);
		String str="";
		if(num>0){
			str="ok";
		}else{
			str="fail";
		}
		  return str;				  
	   }
	
	//验证登录 获取json格式
	@RequestMapping("/toJsonMain")
	public @ResponseBody String toJsonMain(@RequestBody UsersCustom  usersCustom ) throws Exception{
			
		UsersCustom userList  =usersService.selectUserIf(usersCustom);
		String str="";
		if(userList!=null){
			Integer num=userList.getUserid();
			
			if(num>0){
				str="ok";
			}else{
				str="fail";
			}
			
		}
		  return str;				     	
	}
	
     @RequestMapping("/SelectAllOffice")
	 public  @ResponseBody List<Office> SelectAllOffice() throws Exception{
	
		List<Office> list=usersService.selectOfficeAll();
		
		return list;
				
	}
	
     @RequestMapping("/SelectOutPatientById")
    public @ResponseBody List<Outpatientservice> SelectOutPatientById(HttpServletRequest request) throws Exception{
    	 
    	 Integer officeId=new Integer(request.getParameter("officeid")) ;
    	
    	 List<Outpatientservice>  list=usersService.selectOutPatById(officeId);
    	
    	 return list;
        	
    }
	   

}
