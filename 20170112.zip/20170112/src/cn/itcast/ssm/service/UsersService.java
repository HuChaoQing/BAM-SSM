package cn.itcast.ssm.service;

import java.util.List;

import cn.itcast.ssm.po.Office;
import cn.itcast.ssm.po.Outpatientservice;
import cn.itcast.ssm.po.UsersCustom;

public interface UsersService {
	
	public Integer insertUser(UsersCustom usersCustom) throws Exception;
	
	public UsersCustom selectUserIf(UsersCustom usersCustom)throws Exception;

	public List<Office> selectOfficeAll() throws Exception;
	
	public List<Outpatientservice> selectOutPatById(Integer officeId) throws Exception;
}
