package cn.itcast.ssm.service.impl;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import cn.itcast.ssm.mapper.OfficeMapper;
import cn.itcast.ssm.mapper.OutpatientserviceMapper;
import cn.itcast.ssm.mapper.OutpatientserviceMapperCustom;
import cn.itcast.ssm.mapper.UsersMapper;
import cn.itcast.ssm.mapper.UsersMapperCustom;
import cn.itcast.ssm.po.Office;
import cn.itcast.ssm.po.Outpatientservice;
import cn.itcast.ssm.po.UsersCustom;
import cn.itcast.ssm.service.UsersService;

public class UsersServiceImpl implements UsersService {
	
	@Autowired 
	private UsersMapper usersMapper;
	
	@Autowired
	private UsersMapperCustom usersMapperCustom;
	
	@Autowired
	private OfficeMapper officeMapper;
	
	@Autowired
	private OutpatientserviceMapperCustom outpatientserviceMapperCustom;

	public Integer insertUser(UsersCustom usersCustom) throws Exception {
		// TODO Auto-generated method stub
		Integer num=usersMapper.insert(usersCustom);
		return num;
	}

	public UsersCustom selectUserIf(UsersCustom usersCustom) throws Exception {
		  
		UsersCustom user=usersMapperCustom.findUserToLogim(usersCustom);
		 
		return user;
	}

	public List<Office> selectOfficeAll() throws Exception {
		
		List<Office> offer=	 officeMapper.selectByExample(null);
		
		return offer;
			
	}

	public List<Outpatientservice> selectOutPatById(Integer officeId) throws Exception {
	
		
		List<Outpatientservice> outpatient= outpatientserviceMapperCustom.selectOutPatById(officeId);
		return outpatient;
		
	}

	
	

}
